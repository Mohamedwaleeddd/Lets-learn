// Show Side Bar
const line = document.querySelector('.line');
const line2 = document.querySelector('.line2');
const line3 = document.querySelector('.line3');
const menuBox = document.querySelector('aside');

menuBox.style.right = "-200%";

function show() {
  if (menuBox.style.right === "-200%") {
    line2.style.marginBottom = "5px";
    line2.style.position = "absolute";
    line2.style.transform = "rotate(130deg)";
    line.style.transform = "rotate(50deg)";
    line.style.marginTop = "1px";
    menuBox.style.right = "0px";
    line3.style.display = "none";
  }

  else if (menuBox.style.right === "0px") {
    line2.style.marginBottom = "0px";
    line2.style.position = "relative";
    line2.style.transform = "rotate(0deg)";
    line.style.transform = "rotate(0deg)";
    line3.style.display = "block";

    menuBox.style.right = "-200%";
  }
}

//Arrow Up Btn
const arrowUp = document.getElementById("arrow-up");

window.addEventListener("scroll", () => {
  if (document.body.scrollTop >= 100 || document.documentElement.scrollTop >= 100) {
    arrowUp.style.display = "block";
  } else {
    arrowUp.style.display = "none";
  }
});
arrowUp.addEventListener("click", () => {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
});

//Show And Hide The About Box
const about = document.querySelector(".about-box");
about.style.top = "-100%";
function removeAboutBox(){
  about.style.top = "-100%";
}

function showAboutBox(){
  about.style.top = "50%";
}